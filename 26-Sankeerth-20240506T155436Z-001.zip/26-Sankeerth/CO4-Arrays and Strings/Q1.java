import java.util.Scanner;

class Employee {
    private int eNo;
    private String eName;
    private double eSalary;

    public Employee(int eNo, String eName, double eSalary) {
        this.eNo = eNo;
        this.eName = eName;
        this.eSalary = eSalary;
    }

    public int getENo() {
        return eNo;
    }

    public String getEName() {
        return eName;
    }

    public double getESalary() {
        return eSalary;
    }
}

public class Q1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of employees: ");
        int n = scanner.nextInt();
        scanner.nextLine();

        Employee[] employees = new Employee[n];

        
        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for employee " + (i + 1) + ":");
            System.out.print("Employee Number: ");
            int eNo = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Employee Name: ");
            String eName = scanner.nextLine();
            System.out.print("Employee Salary: ");
            double eSalary = scanner.nextDouble();
            scanner.nextLine(); 

            employees[i] = new Employee(eNo, eName, eSalary);
        }

       
        System.out.print("\nEnter the employee number to search: ");
        int searchENo = scanner.nextInt();

        boolean found = false;
        for (Employee employee : employees) {
            if (employee.getENo() == searchENo) {
                System.out.println("\nEmployee found:");
                System.out.println("Employee Number: " + employee.getENo());
                System.out.println("Employee Name: " + employee.getEName());
                System.out.println("Employee Salary: " + employee.getESalary());
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("\nEmployee with Employee Number " + searchENo + " not found.");
        }

        scanner.close();
    }
}
