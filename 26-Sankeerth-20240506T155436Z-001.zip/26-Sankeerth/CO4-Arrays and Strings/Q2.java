public class Q2 {
    public static void main(String[] args) {
        String str = "Welcome,Champs!";

        int length = str.length();
        System.out.println("Length of the string: " + length);

        String uppercaseStr = str.toUpperCase();
        System.out.println("Uppercase string: " + uppercaseStr);

       
        String lowercaseStr = str.toLowerCase();
        System.out.println("Lowercase string: " + lowercaseStr);

        
        String substring = str.substring(7); // Start index is inclusive
        System.out.println("Substring from index 7: " + substring);

    
        String concatStr = str.concat(" This is Java.");
        System.out.println("Concatenated string: " + concatStr);

        String replacedStr = str.replace('o', 'x');
        System.out.println("String after replacing 'o' with 'x': " + replacedStr);

       
        int index = str.indexOf('o');
        System.out.println("Index of 'o': " + index);

        boolean startsWithHello = str.startsWith("Hello");
        boolean endsWithWorld = str.endsWith("World!");
        System.out.println("Starts with 'Hello': " + startsWithHello);
        System.out.println("Ends with 'World!': " + endsWithWorld);
    }
}
