import java.util.Scanner;

class employee
{
int empid;
String name;
double salary;
String address;
public employee(int empid,String name,double salary,String address)
{
    this.empid = empid;
    this.name = name;
    this.salary = salary;
    this.address = address;
}
}

class teacher extends employee
{
String department;
String subject;
public teacher(int empid,String name,double salary,String address,String department,String subject)
{
    super(empid,name,salary,address);
    this.department = department;
    this.subject = subject;
}
public void display()
{
    System.out.println("Employee ID: " + empid);
    System.out.println("Name: " + name);
    System.out.println("Salary: " + salary);
    System.out.println("Address: " + address);
    System.out.println("Department: " + department);
    System.out.println("Subjects: " + subject);
    System.out.println();
}
}

public class Q1 
{
public static void main(String[] args) 
{
    Scanner s = new Scanner(System.in);
    System.out.print("Enter the number of teachers (N): ");
        int n = s.nextInt();

        teacher[] teachers = new teacher[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Teacher " + (i + 1) + ":");
            System.out.print("Employee ID: ");
            int empId = s.nextInt();
            s.nextLine();
            System.out.print("Name: ");
            String name = s.nextLine();
            System.out.print("Salary: ");
            double salary = s.nextDouble();
            s.nextLine(); 
            System.out.print("Address: ");
            String address = s.nextLine();
            System.out.print("Department: ");
            String department = s.nextLine();
            System.out.print("Subjects: ");
            String subjects = s.nextLine();

    
            teachers[i] = new teacher(empId, name, salary, address, department, subjects);
        }

        System.out.println("\nDetails of " + n + " Teachers:");
        for (teacher teacher : teachers) {
            teacher.display();
        }

        s.close();  
}
    
}