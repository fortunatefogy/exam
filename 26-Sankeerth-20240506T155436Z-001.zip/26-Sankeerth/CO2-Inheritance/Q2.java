import java.util.Scanner;

class Person {
    String name;
    String gender;
    String address;
    int age;

    public Person(String name, String gender, String address, int age) {
        this.name = name;
        this.gender = gender;
        this.address = address;
        this.age = age;
    }
}

class Employee1 extends Person {
    String empid;
    String company_name;
    String qualification;
    double salary;

    public Employee1(String name, String gender, String address, int age, String empid, String company_name, String qualification, double salary) {
        super(name, gender, address, age);
        this.empid = empid;
        this.company_name = company_name;
        this.qualification = qualification;
        this.salary = salary;
    }
}

class Teacher1 extends Employee1 {
    String subject;
    String department;
    String teacher_id;

    public Teacher1(String name, String gender, String address, int age, String empid, String company_name, String qualification, double salary, String subject, String department, String teacher_id) {
        super(name, gender, address, age, empid, company_name, qualification, salary);
        this.subject = subject;
        this.department = department;
        this.teacher_id = teacher_id;
    }

    public void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);
        System.out.println("Address: " + address);
        System.out.println("Age: " + age);
        System.out.println("Employee ID: " + empid);
        System.out.println("Company Name: " + company_name);
        System.out.println("Qualification: " + qualification);
        System.out.println("Salary: " + salary);
        System.out.println("Subject: " + subject);
        System.out.println("Department: " + department);
        System.out.println("Teacher ID: " + teacher_id);
        System.out.println();
    }
}

public class Q2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of teachers: ");
        int N = scanner.nextInt();
        scanner.nextLine(); // Consume newline character left by nextInt()

        Teacher1[] teachers = new Teacher1[N];

        for (int i = 0; i < N; i++) {
            System.out.println("Enter details for teacher " + (i + 1) + ":");
            System.out.print("Name: ");
            String name = scanner.nextLine();
            System.out.print("Gender: ");
            String gender = scanner.nextLine();
            System.out.print("Address: ");
            String address = scanner.nextLine();
            System.out.print("Age: ");
            int age = scanner.nextInt();
            scanner.nextLine(); // Consume newline character left by nextInt()
            System.out.print("Employee ID: ");
            String empid = scanner.nextLine();
            System.out.print("Company Name: ");
            String company_name = scanner.nextLine();
            System.out.print("Qualification: ");
            String qualification = scanner.nextLine();
            System.out.print("Salary: ");
            double salary = scanner.nextDouble();
            scanner.nextLine(); // Consume newline character left by nextDouble()
            System.out.print("Subject: ");
            String subject = scanner.nextLine();
            System.out.print("Department: ");
            String department = scanner.nextLine();
            System.out.print("Teacher ID: ");
            String teacher_id = scanner.nextLine();

            teachers[i] = new Teacher1(name, gender, address, age, empid, company_name, qualification, salary, subject, department, teacher_id);
        }

        System.out.println("\nDetails of Teachers:");

        for (Teacher1 teacher : teachers) {

            teacher.displayDetails();

        }

        scanner.close();

    }

}