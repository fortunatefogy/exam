import java.util.*;

abstract class Acc {
    double bal;

    public Acc(double bal) {
        this.bal = bal;
        System.out.print("The balance amount is :" + bal);
    }

    public abstract void deposit(double amount);

    public abstract void withdraw(double amount);

    public double getbal() {
        return bal;
    }
}

class SA extends Acc {
    public SA(double bal) {
        super(bal);
    }

    public void deposit(double amount) {
        bal = bal + amount;
        System.out.println("$" + amount + " is deposited and the new Balance is " + bal);
    }

    public void withdraw(double amount) {
        if (amount <= bal) {
            bal = bal - amount;
            System.out.println("$" + amount + " is withdrawn and the new Balance is " + bal);
        } else {
            System.out.println("Insufficient Balance");
        }
    }
}

public class Q3 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        double ib;
        System.out.print("Enter the initial Balance:");
        ib = s.nextDouble();
        SA a = new SA(ib);
        int ch;
        double am;

        do {
            System.out.println("\n1.Check Balance");
            System.out.println("2.Deposit");
            System.out.println("3.Withdraw");
            System.out.println("4.Exit");
            System.out.println("Enter your choice:");
            ch = s.nextInt();
            switch (ch) {
                case 1:
                    System.out.println("Balance: $" + a.getbal());
                    break;
                case 2:
                    System.out.println("Enter the amount to be deposited:");
                    am = s.nextDouble();
                    a.deposit(am);
                    break;
                case 3:
                    System.out.println("Enter the amount to be withdrawn:");
                    am = s.nextDouble();
                    a.withdraw(am);
                    break;
                case 4:
                    System.out.println("Thanks for Banking...");
                    break;
                default:
                    System.out.println("Wrong Choice!!!");
                    break;
            }
        } while (ch != 4);
    }
}