import java.util.Scanner;

interface Vehicle {
    void displayInfo();
}

class Loan implements Vehicle {
    private double loanAmount;
    private int duration;

    public Loan(double loanAmount, int duration) {
        this.loanAmount = loanAmount;
        this.duration = duration;
    }

    public void displayInfo() {
        System.out.println("Vehicle Loan Information:");
        System.out.println("Loan Amount: $" + loanAmount);
        System.out.println("Duration: " + duration + " years");
    }
}

class Insurance implements Vehicle {
    private double vehicleValue;

    public Insurance(double vehicleValue) {
        this.vehicleValue = vehicleValue;
    }

    public void displayInfo() {
        System.out.println("Vehicle Insurance Information:");
        System.out.println("Vehicle Value: $" + vehicleValue);
        System.out.println("Premium: $" + calculatePremium());
    }

    private double calculatePremium() {
        double premiumPercentage = 5.0;
        return (vehicleValue * premiumPercentage) / 100;
    }
}

public class Q2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Vehicle Loan Amount: $");
        double loanAmount = scanner.nextDouble();

        System.out.println("Select a preferred duration plan:");
        System.out.println("1. 8% interest (duration - 3 years)");
        System.out.println("2. 9% interest (duration - 4 years)");
        System.out.println("3. 10% interest (duration - 5 years)");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        int duration = 0;
        switch (choice) {
            case 1:
                duration = 3;
                break;
            case 2:
                duration = 4;
                break;
            case 3:
                duration = 5;
                break;
            default:
                System.out.println("Wrong input!");
                System.exit(0);
        }

        double totalAmount = loanAmount * (1 + choice * 0.01) * duration;
        double monthlyPayment = totalAmount / (duration * 12);
        System.out.println("Total amount to pay after " + duration + " years: $" + totalAmount);
        System.out.println("Monthly payment: $" + monthlyPayment);

        Vehicle loan = new Loan(loanAmount, duration);
        loan.displayInfo();

        System.out.print("\nEnter Vehicle Value: $");
        double vehicleValue = scanner.nextDouble();

        Vehicle insurance = new Insurance(vehicleValue);
        insurance.displayInfo();

        scanner.close();
    }
}
