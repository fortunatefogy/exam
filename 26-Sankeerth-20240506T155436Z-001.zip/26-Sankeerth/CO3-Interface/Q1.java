import java.util.Scanner;
public interface shape 
{
double area();
double perimeter();  
}

class Circle implements shape
{
    private double r;
    public Circle(double r)
    {
    this.r=r;
    }

    public double area()
    {
        return Math.PI*r*r;
    }
    public double perimeter()
    {
        return Math.PI*r*2;
    }
}

class Rectangle implements shape
{
    private double l,b;
    public Rectangle(double l,double b)
    {
    this.l=l;
    this.b=b;
    }

    public double area()
    {
        return l*b;
    }
    public double perimeter()
    {
        return 2*(l+b);
    }
}

class Q1
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Circle");
        System.out.print("Enter the radius of circle: ");
        double radius=s.nextDouble();
        Circle c=new Circle(radius);
        System.out.print("\nArea of circle : "+c.area());
        System.out.print("\nPerimeter of Circle : "+c.perimeter());
        
        System.out.println("\n++++++++++++++++++++");

        System.out.println("Rectangle");
        System.out.print("Enter the length of Rectangle: ");
        double length=s.nextDouble();
        System.out.print("\nEnter the breadth of Rectangle: ");
        double breadth=s.nextDouble();
        Rectangle r=new Rectangle(length,breadth);
        System.out.print("\nArea of Rectangle : "+r.area());
        System.out.print("\nPerimeter of Rectangle : "+r.perimeter());
        
    }
}