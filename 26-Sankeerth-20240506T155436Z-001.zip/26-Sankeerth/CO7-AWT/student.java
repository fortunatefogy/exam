import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class student extends JFrame implements ActionListener {
    
     JTextField nameField, rollNoField, addressField;
     JComboBox<String> genderComboBox, courseComboBox;
     JTextField[] marksFields;
     JButton gradeButton;
     JLabel totalMarksLabel, gradeLabel;

    public student() {
        setTitle("Student Management System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);


        nameField = new JTextField(20);
        rollNoField = new JTextField(20);
        addressField = new JTextField(20);

        genderComboBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        courseComboBox = new JComboBox<>(new String[]{"Course 1", "Course 2", "Course 3"});

        marksFields = new JTextField[3];
        for (int i = 0; i < 3; i++) {
            marksFields[i] = new JTextField(5);
        }

        gradeButton = new JButton("Grade");
        gradeButton.addActionListener(this);

        totalMarksLabel = new JLabel("Total Marks:");
        gradeLabel = new JLabel("Grade:");


        setLayout(new GridLayout(8, 2));
        add(new JLabel("Name:"));
        add(nameField);
        add(new JLabel("Gender:"));
        add(genderComboBox);
        add(new JLabel("Course:"));
        add(courseComboBox);
        add(new JLabel("Roll No:"));
        add(rollNoField);
        add(new JLabel("Address:"));
        add(addressField);
        add(new JLabel("Marks 1:"));
        add(marksFields[0]);
        add(new JLabel("Marks 2:"));
        add(marksFields[1]);
        add(new JLabel("Marks 3:"));
        add(marksFields[2]);
        add(gradeButton);
        add(totalMarksLabel);
        add(gradeLabel);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == gradeButton) {
            int totalMarks = 0;
            for (JTextField marksField : marksFields) {
                totalMarks += Integer.parseInt(marksField.getText());
            }
            totalMarksLabel.setText("Total Marks: " + totalMarks);

            double averageMarks = totalMarks / 3.0;
            if (averageMarks >= 90) {
                gradeLabel.setText("Grade: A");
            } else if (averageMarks >= 80) {
                gradeLabel.setText("Grade: B");
            } else if (averageMarks >= 70) {
                gradeLabel.setText("Grade: C");
            } else if (averageMarks >= 60) {
                gradeLabel.setText("Grade: D");
            } else {
                gradeLabel.setText("Grade: F");
            }
        }
    }

    public static void main(String[] args) {
        new student();
    }
}
