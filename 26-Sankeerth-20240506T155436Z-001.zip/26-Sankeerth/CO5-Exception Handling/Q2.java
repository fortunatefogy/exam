
import java.util.*;
class NE extends Exception {
    public NE(String message) {
        super(message);
    }
}
class Q2 {
    public static void main(String[] args) {
        int i,n,sum=0,av=0;
        Scanner s=new Scanner(System.in);
        System.out.print("Enter the size:");
        n=s.nextInt();
        int[] a=new int[n];
        System.out.println("The Elements are:");
        for(i=0;i<n;i++)
        {
            a[i]=s.nextInt();
        }
        try
        {
            for(i=0;i<n;i++)
            {
                if(a[i]<0)
                {
                    throw new NE("Negative number found");
                }
                sum+=a[i];
                av=sum/n;
            }
            System.out.println("Average is:"+av);
        }
        catch(NE e)
        {
            System.out.println("Error "+e.getMessage());
        }
    }
}