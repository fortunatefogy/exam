import java.util.*;
class AExptn extends Exception {
    public AExptn(String message) {
        super(message);
    }
}

class Q1{
    private static final String u = "admin";
    private static final String p = "admin";

    public static void authenticate(String username, String password) throws AExptn {
        if (!u.equals(username) || !p.equals(password)) {
            throw new AExptn("Invalid username or password.");
        }
        System.out.println("Authentication successful!");
    }

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String user,pass;
        System.out.print("Enter the username:");
        user=s.nextLine();
        System.out.print("\nEnter the password:");
        pass=s.nextLine();
        
        try {
            authenticate(user,pass);
        } catch (AExptn e) {
            System.out.println("Authentication failed: " + e.getMessage());
        }
    }
}