import java.util.Scanner;

class Prod {
    Scanner s = new Scanner(System.in);
    int pcode;
    String pname;
    double price;

    void details(int i) {
        
        System.out.print("\nEnter product"+i+" code:");
        pcode = s.nextInt();
        s.nextLine();
        System.out.print("\nEnter product"+i+" name:");
        pname = s.nextLine();
        System.out.print("\nEnter product"+i+" prize:");
        price = s.nextDouble();
        
    }

    void display() {
        System.out.println("\nProduct code: " + pcode + "\t" + "Product name: " + pname + "\t" + "Price: " + price);
    }

    static void lowest(Prod p1, Prod p2, Prod p3) {
        if (p1.price < p2.price && p1.price < p3.price) {
            System.out.println("\nProduct 1 is of the lowest price.");
        } else if (p2.price < p1.price && p2.price < p3.price) {
            System.out.println("\nProduct 2 is of the lowest price.");
        } else {
            System.out.println("\nProduct 3 is of the lowest price.");
        }
    }
}

public class Q1 {
    public static void main(String[] args) {
        
        Prod ob1 = new Prod();
        Prod ob2 = new Prod();
        Prod ob3 = new Prod();

        ob1.details(1);
        ob2.details(2);
        ob3.details(3);

        ob1.display();
        ob2.display();
        ob3.display();

        Prod.lowest(ob1, ob2, ob3);
    }
}
